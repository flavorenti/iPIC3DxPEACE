import fibo as fb
import matplotlib
import matplotlib.pyplot as plt
import matplotlib.cm as cm
import numpy as np



#########################################################################
########### Load the cusps ##############################################
#########################################################################
def load_cusp(input_file_cusp,proj=None):

    # load txt file with values cusp thresold
    phi_c,theta_c,comment = np.loadtxt(input_file_cusp,unpack=True,dtype='str')
    lot_cusp = np.array(phi_c,dtype='float')*24./(2*np.pi)
    lat_cusp = 90.-(np.array(theta_c,dtype='float')*180./np.pi)
    x_cusp=[]
    y_cusp=[]
    for i in range(0,len(phi_c)):
        if lot_cusp[i] not in x_cusp:
            if len(lat_cusp[(phi_c==phi_c[i])*(lat_cusp>0)])>0:
                x_cusp.append(lot_cusp[i])
                y_cusp.append(np.min(lat_cusp[(phi_c==phi_c[i])*(lat_cusp>0)]))
            if len(lat_cusp[(phi_c==phi_c[i])*(lat_cusp<0)])>0:
                x_cusp.append(lot_cusp[i])
                y_cusp.append(np.max(lat_cusp[(phi_c==phi_c[i])*(lat_cusp<0)]))
    x_cusp = np.array(x_cusp)
    y_cusp = np.array(y_cusp)
    x_cuspN = x_cusp[np.where(y_cusp>0)]
    y_cuspN = y_cusp[np.where(y_cusp>0)]
    x_cuspS = x_cusp[np.where(y_cusp<0)]
    y_cuspS = y_cusp[np.where(y_cusp<0)]

    # convert to good units for mollweide proj.
    if proj is not None:
        x_cuspN = (x_cuspN-12.)/12.*np.pi    
        x_cuspS = (x_cuspS-12.)/12.*np.pi    
        y_cuspN = y_cuspN/90.*(np.pi/2.)    
        y_cuspS = y_cuspS/90.*(np.pi/2.) 

    print('CUSP LOADED -->'+input_file_cusp)
    
    return [[x_cuspN,y_cuspN],[x_cuspS,y_cuspS]]



#########################################################################
####### Load Latitude-LT map from prec. file  ###########################
#########################################################################
def load_prec(input_file_prec,proj=None):

    data_prec = np.loadtxt(input_file_prec[0])

    # grid coordinates
    lot = data_prec[0][1:]
    lat = []
    for iy,line in enumerate(data_prec):
        if iy>0:
            lat = np.append(lat,line[0])

    # convert grid to good units for mollweide proj.
    if proj is not None:
        lot = (lot-12.)/12.*np.pi
        lat = lat/90.*(np.pi/2.)

    # create grid    
    Lot,Lat = np.meshgrid(lot,lat)

    # actual data load 1st file
    histo = np.zeros((len(lot),len(lat)))
    for iy,line in enumerate(data_prec):
        if iy>0:
            histo[:,iy-1]=line[1:]

    # if 2nd file exist load it too and MULTIPLY by histo
    if len(input_file_prec)>1 :
        data_prec = np.loadtxt(input_file_prec[1])
        for iy,line in enumerate(data_prec):
            if iy>0:
                if 'Flux' in input_file_prec[1]:
                    histo[:,iy-1] += line[1:]
                elif 'Ener' in input_file_prec[1]:
                    histo[:,iy-1] *= line[1:]

    # print status
    print('GRID LatxLT LOADED -->'+input_file_prec[0])
    if len(input_file_prec)>1 :
        print('MAP LatxLT LOADED WITH %i files'%len(input_file_prec))
    if len(input_file_prec)>1 :
        if 'Flux' in input_file_prec[1]:
            histo /= 2.

    return [histo,Lot,Lat]



#########################################################################
########### Put plot in given axis  #####################################
#########################################################################
def plot_data(ax,input_file_prec,input_file_cusp=None,proj=None,xlab=0):

    # open cusp data
    if input_file_cusp is not None:
        cusp = load_cusp(input_file_cusp,proj)
    
    # open prec map data
    prec = load_prec(input_file_prec,proj)

    # define pars plot for two cases
    if len(input_file_prec)==1:
        if 'Flux' in input_file_prec[0]:
            cmm = cm.Reds
            vlim = [1e6,1e9]
            clab = r'$\frac{pcls}{cm^2 s}$'
        else:
            cmm = cm.coolwarm
            vlim = [2e1,4e4]
            clab = r'$eV$'
    else:
        if 'Flux' in input_file_prec[1]:
            cmm = cm.Reds
            vlim = [1e6,1e9]
            clab = r'$\frac{pcls}{cm^2 s}$'
        else:
            cmm = cm.coolwarm
            vlim = [1e8,1e13]
            clab = r'$\frac{eV}{cm^2 s}$'
 
    # plot actual data
    im = ax.pcolormesh(prec[1],prec[2],np.transpose(prec[0]),norm=matplotlib.colors.LogNorm(),vmin=vlim[0],vmax=vlim[1],cmap=cmm)
    
    # plot cusps thresolds
    if input_file_cusp is not None:
        ax.plot(cusp[0][0],cusp[0][1],linestyle='--',marker='',color='black')
        ax.plot(cusp[1][0],cusp[1][1],linestyle='--',marker='',color='black')

    # define extra fancy plot pars
    if proj is not None:
        plt.yticks([-np.pi/2,-np.pi/3,-np.pi/6,0,np.pi/6,np.pi/3],fontsize=14)
        plt.xticks([-np.pi*0.98,-np.pi*3/4,-np.pi/2,-np.pi/4.,0,np.pi/4,np.pi/2,np.pi*3/4,np.pi*0.98],fontsize=14)
        if not xlab:
            ax.set_xticklabels(['0','3','6','9','12','15','18','21','24'],fontsize=14)
        else:
            ax.set_xticklabels([])
    else:
        plt.yticks(fontsize=14)
        plt.xticks(fontsize=14)

    plt.grid(alpha=0.6)
    #ax.hlines(np.pi/20.,-np.pi,np.pi,linestyle='--',color='grey')

    return im,clab




#########################################################################
################# Main of the code  #####################################
#########################################################################
def main(input_file_prec,input_file_cusp=None,proj=None):


    # number of plots
    Nplots = len(input_file_prec)
    if Nplots%2==0 and Nplots<10 :
        Nx = Nplots/2
        Ny = 2
    elif Nplots%2==1 and Nplots<10 :
        Nx = (Nplots+1)/2
        Ny = 2
    elif Nplots>10 :
        Nx = Nplots/3
        Ny = 3

    #extra
    #Nx = 1
    #Ny = 1

    fig_size = (Nx*8,Ny*4) #6,4

    # do the picture
    fig = plt.figure(figsize=fig_size)

    # do the plots
    for ip in range(0,Nplots):
        print('DO PLOTS -->',Ny,Nx,ip+1)
        ax = fig.add_subplot(Ny, Nx, ip+1, projection=proj)
        im,clab = plot_data(ax,input_file_prec[ip],input_file_cusp[ip],proj,xlab=ip)
        ll = input_file_prec[ip][0].split('_')[2]
        #ax.set_title(ll,fontsize=12)

        if proj is not None:

            # add colorbar1 Flux
            if ip==0 :
                cax1 = fig.add_axes([0.11, 0.12, 0.37, 0.012])
                cb1 = fig.colorbar(im, cax=cax1, orientation='horizontal')
                cb1.set_label(clab,rotation=0,fontsize=20)
                cb1.ax.tick_params(labelsize=16)

            # add colorbar2 Energy
            if ip==1:
                cax2 = fig.add_axes([0.54, 0.12, 0.37, 0.012])
                cb2 = fig.colorbar(im, cax=cax2, orientation='horizontal')
                cb2.set_label(clab,rotation=0,fontsize=20)
                cb2.ax.tick_params(labelsize=16)
        else:
            if ip>1:
                ax.set_xlabel('Local time [h]',fontsize=16)
            ax.set_ylabel('Latitude [deg]',fontsize=16)
            cb = fig.colorbar(im)
            cb.set_label(clab,rotation=0,fontsize=20)
            cb.ax.tick_params(labelsize=16)
            plt.xlim(0,24)
            plt.ylim(-90,90)

    # add text
    plt.figtext(0.4,0.9,'Northward IMF',fontsize=32)
    plt.figtext(0.4,0.45,'Southward IMF',fontsize=32)

    # save figure and close
    if proj is not None:
        plt.subplots_adjust(top=0.95,bottom=0.1,wspace=0.2, hspace=0.0)
    else:
        plt.subplots_adjust(top=0.87,bottom=0.1,wspace=0.2, hspace=0.4)
    plt.savefig('images/'+save_name+'.png',format='png')
    plt.show()
    plt.close()


# cusps
cuspPR0mBz = 'texts/output_cusps_PR0-minusBz_5000.txt'
cuspPR0pBz = 'texts/output_cusps_PR0-plusBz_6400.txt'
cuspPR1mBz = 'texts/output_cusps_PR1-minusBz_6500.txt'
cuspPR1pBz = 'texts/output_cusps_PR1-plusBz_6000.txt'

# PR0
precPR0mBzFe = 'texts/output_precipitation_PR0-minusBz_Flux-e.txt'
precPR0mBz1Fe = 'texts/output_precipitation_PR0-minusBz_0-100s_Flux-e.txt'
precPR0mBz2Fe = 'texts/output_precipitation_PR0-minusBz_100-1000s_Flux-e.txt'
precPR0mBz3Fe = 'texts/output_precipitation_PR0-minusBz_1000s-inf_Flux-e.txt'
precPR0pBzFe = 'texts/output_precipitation_PR0-plusBz_Flux-e.txt'
precPR0pBz1Fe = 'texts/output_precipitation_PR0-plusBz_0-100s_Flux-e.txt'
precPR0pBz2Fe = 'texts/output_precipitation_PR0-plusBz_100-1000s_Flux-e.txt'
precPR0pBz3Fe = 'texts/output_precipitation_PR0-plusBz_1000s-inf_Flux-e.txt'
#PR1
precPR1mBzFe = 'texts/output_precipitation_PR1-minusBz_Flux-e.txt'
precPR1mBz1Fe = 'texts/output_precipitation_PR1-minusBz_0-100s_Flux-e.txt'
precPR1mBz2Fe = 'texts/output_precipitation_PR1-minusBz_100-1000s_Flux-e.txt'
precPR1mBz3Fe = 'texts/output_precipitation_PR1-minusBz_1000s-inf_Flux-e.txt'
precPR1pBzFe = 'texts/output_precipitation_PR1-plusBz_Flux-e.txt'
precPR1pBz1Fe = 'texts/output_precipitation_PR1-plusBz_0-100s_Flux-e.txt'
precPR1pBz2Fe = 'texts/output_precipitation_PR1-plusBz_100-1000s_Flux-e.txt'
precPR1pBz3Fe = 'texts/output_precipitation_PR1-plusBz_1000s-inf_Flux-e.txt'

# map list
ml = []
for simu in [precPR1pBzFe,precPR1pBz1Fe,precPR1pBz2Fe,precPR1pBz3Fe]:
    simu = simu.replace('-e','-i')
    #ml.append([simu])
    ml.append([simu,simu.replace('Flux','Ener')]) 
for simu in [precPR1pBzFe,precPR1pBz1Fe,precPR1pBz2Fe,precPR1pBz3Fe]:
    simu = simu.replace('-e','-i')
    simu = simu.replace('plus','minus')
    #ml.append([simu])
    ml.append([simu,simu.replace('Flux','Ener')]) 

# cusp list
cl = []
for i in range(4):
    cl.append(cuspPR1pBz) 
for i in range(4):
    cl.append(cuspPR1mBz)

save_name = 'Composite_PR1-good_En-Fluxes_All_i'
main(ml,cl,None)

